<?php
include 'config.php';
if (isset($_POST['add'])) {
  $task = mysqli_real_escape_string($db, $_POST['task']);
  mysqli_query($db, "INSERT INTO task (task) VALUES ('$task')");
}
header('Location: index.php');
?>