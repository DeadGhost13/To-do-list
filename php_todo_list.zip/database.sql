CREATE DATABASE IF NOT EXISTS todo_list;
USE todo_list;
CREATE TABLE task (
  task_id INT AUTO_INCREMENT PRIMARY KEY,
  task VARCHAR(250) NOT NULL,
  status ENUM('Pending','Done') NOT NULL DEFAULT 'Pending'
);