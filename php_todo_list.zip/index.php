<?php include 'config.php'; ?>
<!DOCTYPE html><html><head><link rel="stylesheet" href="styles.css"></head><body>
<h1>To‑Do List</h1>
<form method="POST" action="add_task.php">
  <input type="text" name="task" placeholder="Enter task..." required>
  <button name="add">Add</button>
</form>
<table>
  <tr><th>ID</th><th>Task</th><th>Status</th><th>Actions</th></tr>
  <?php
  $result = mysqli_query($db, "SELECT * FROM task");
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>
      <td>{$row['task_id']}</td>
      <td>{$row['task']}</td>
      <td>{$row['status']}</td>
      <td>
        <a href='edit_task.php?id={$row['task_id']}'>Edit</a> |
        <a href='delete_task.php?id={$row['task_id']}'
           onclick=\"return confirm('Delete?')\">Delete</a>
      </td>
    </tr>";
  }
  ?>
</table>
</body></html>