<?php
include 'config.php';
if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  mysqli_query($db, "DELETE FROM task WHERE task_id=$id");
}
header('Location: index.php');
?>