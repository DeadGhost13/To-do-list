<?php
$db = mysqli_connect("localhost","root","","todo_list")
  or die("Connection failed: " . mysqli_connect_error());
?>