<?php
include 'config.php';
if (isset($_GET['id'])) {
  $id = intval($_GET['id']);
  if (isset($_POST['update'])) {
    $task = mysqli_real_escape_string($db, $_POST['task']);
    $status = $_POST['status'];
    mysqli_query($db, "UPDATE task SET task='$task', status='$status' WHERE task_id=$id");
    header('Location: index.php');
  }
  $row = mysqli_fetch_assoc(mysqli_query($db, "SELECT * FROM task WHERE task_id=$id"));
?>
<form method="POST">
  <input name="task" value="<?=htmlspecialchars($row['task'])?>" required>
  <select name="status">
    <option value="Pending" <?= $row['status']=='Pending'? 'selected':''?>>Pending</option>
    <option value="Done" <?= $row['status']=='Done'? 'selected':''?>>Done</option>
  </select>
  <button name="update">Update</button>
</form>
<?php } ?>